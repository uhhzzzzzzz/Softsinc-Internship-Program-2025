def log_to_file(message):
    with open('log.txt','a')as file:
        file.write(message + '\n')

class User:
    def login(self):
        log_to_file("User logged in")
        print("User logged in")

class Intern(User):
    def send_message(self, message):
        log_to_file(f"Intern sent message: {message}")
        print("Intern sent a message")

class Admin:
    def __init__(self, user):
        self.user = user

    def delete_user(self, user_id):
        log_to_file(f"Admin deleted user with ID: {user_id}")
        print(f"Deleted user {user_id}")

u = User()
u.login()

i = Intern()
i.send_message("Hello, team!")

a = Admin(u)
a.delete_user(101)
