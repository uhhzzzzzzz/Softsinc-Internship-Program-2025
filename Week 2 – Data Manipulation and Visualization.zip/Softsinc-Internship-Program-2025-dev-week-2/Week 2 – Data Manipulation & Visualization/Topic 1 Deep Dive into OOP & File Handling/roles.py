from logger_utils import log_action

class Intern:
    def complete_task(self, task_name):
        log_action("intern.log", f"Task completed: {task_name}")
        print("Intern did a task.")

class HR:
    def hire_employee(self, employee_name):
        log_action("hr.log", f"Hired employee: {employee_name}")
        print("HR hired someone.")

class Admin:
    def reset_password(self, user_id):
        log_action("admin.log", f"Password reset for user: {user_id}")
        print("Admin reset a password.")
