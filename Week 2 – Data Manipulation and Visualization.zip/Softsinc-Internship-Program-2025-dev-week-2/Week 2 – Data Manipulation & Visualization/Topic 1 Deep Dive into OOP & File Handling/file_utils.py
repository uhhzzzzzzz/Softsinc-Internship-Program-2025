def write_to_file(filename, content):
    with open(filename, "a") as file:
        file.write(content + "\n")

def read_from_file(filename):
    try:
        with open(filename, "r") as file:
            return file.readlines()
    except FileNotFoundError:
        return ["File not found."]
