from roles import Intern, HR, Admin

intern = Intern()
intern.complete_task("Prepare daily report")

hr = HR()
hr.hire_employee("Ali Khan")

admin = Admin()
admin.reset_password("user123")
