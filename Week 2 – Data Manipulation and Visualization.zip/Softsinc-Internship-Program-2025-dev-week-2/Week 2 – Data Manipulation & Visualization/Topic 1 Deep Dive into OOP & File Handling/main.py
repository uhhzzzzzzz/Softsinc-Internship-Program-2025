from file_utils import write_to_file, read_from_file

write_to_file("mylog.txt", "User logged in")
write_to_file("mylog.txt", "Admin created new account")

lines = read_from_file("mylog.txt")

print("File Contents:")
for line in lines:
    print(line.strip())
