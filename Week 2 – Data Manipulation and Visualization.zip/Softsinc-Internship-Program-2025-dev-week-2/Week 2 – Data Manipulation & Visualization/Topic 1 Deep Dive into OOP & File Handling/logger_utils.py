def log_action(filename, message):
    with open(filename, "a") as file:
        file.write(message + "\n")
