class User:
    def show_role(self):
        print("I am a generic user.")

class Intern(User):
    def show_role(self):
        print("I am an Intern.")

class Mentor(User):
    def show_role(self):
        print("I am a Mentor")


class Admin:
    def __init__(self,user):
        self.user=user
    
    def show_role(self):
        print("I am an Admin")

class HR:
    def __init__(self,user):
        self.user=user

    def show_role(self):
        print("I am HR")

def print_role(user):
    user.show_role()


u = User()
i = Intern()
m = Mentor()
a = Admin(u)
h = HR(u)

print_role(u)  # I am a generic user.
print_role(i)  # I am an Intern.
print_role(m)  # I am a Mentor.
print_role(a)  # I am an Admin.
print_role(h)  # I am HR.