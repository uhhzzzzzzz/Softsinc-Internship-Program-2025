#  FastAPI Projects: Student Manager & Automated EDA API

This repository contains two powerful backend APIs built using **FastAPI**:

1. **Student Manager API** – A secure CRUD system for student records with token-based authentication.
2. **EDA Automation API** – Upload a dataset and receive a ready-made PDF EDA report with statistics and plots.

---

##  Project Structure

```
.
├── student_api/
│   ├── main.py
│   ├── models.py
│   ├── database.py
│   ├── auth.py
│
├── eda_api/
│   ├── main.py
│   ├── eda_utils.py
│   ├── eda_output/ (auto-generated)
│   │   ├── summary.txt
│   │   ├── histograms.png
│   │   ├── boxplots.png
│   │   ├── correlation_heatmap.png
│   │   └── EDA_Report.pdf
```

---

##  1. Student Manager API

###  Features
- Create, read, update, delete (CRUD) student records
- Protected routes using `X-Token` headers
- Built-in Swagger UI for testing

###  Roles & Tokens

| Role   | Token              |
|--------|--------------------|
| Admin  | `admin_token_123`  |
| Editor | `editor_token_456` |

###  How to Run

```bash
cd student_api
pip install fastapi uvicorn pydantic
uvicorn main:app --reload
```

###  Endpoints

| Method | URL                   | Description              | Token Required |
|--------|-----------------------|--------------------------|----------------|
| GET    | `/students`           | Get all students         | ❌             |
| GET    | `/students/{id}`      | Get student by ID        | ❌             |
| POST   | `/students`           | Add a student            | ✅             |
| PUT    | `/students/{id}`      | Update student           | ✅             |
| DELETE | `/students/{id}`      | Delete student           | ✅             |

###  Example: Add Student

```bash
curl -X POST "http://127.0.0.1:8000/students" \
  -H "X-Token: admin_token_123" \
  -H "Content-Type: application/json" \
  -d '{"id":1, "name":"Ali", "age":21, "grade":"A"}'
```

---

##  2. EDA Automation API

###  Features
- Upload a `.csv` file and get a full EDA report
- Output includes:
  - Data types & summary
  - Missing value analysis
  - Descriptive statistics
  - Histograms, boxplots & correlation heatmaps
  - Auto-generated PDF report

###  Output Files

Upon upload, EDA results are saved in `/eda_output` including:
- `EDA_Report.pdf`
- `summary.txt`
- Plots (`.png`)

###  How to Run

```bash
cd eda_api
pip install fastapi uvicorn pandas matplotlib seaborn fpdf
uvicorn main:app --reload
```

###  API Routes

| Method | URL                 | Description               |
|--------|---------------------|---------------------------|
| POST   | `/upload`           | Upload CSV and run EDA    |
| GET    | `/download/report`  | Download PDF report       |

###  Upload CSV

```bash
curl -X POST "http://127.0.0.1:8000/upload" \
  -H "accept: application/json" \
  -H "Content-Type: multipart/form-data" \
  -F "file=@titanic.csv;type=text/csv"
```

###  Download PDF Report

```bash
curl -X GET "http://127.0.0.1:8000/download/report"
```

---

##  Sample Output Screenshots (EDA)

| Heatmap                         | Boxplots                       | Histograms                     |
|----------------------------------|--------------------------------|--------------------------------|
| ![](eda_output/correlation_heatmap.png) | ![](eda_output/boxplots.png) | ![](eda_output/histograms.png) |

PDF report also includes tabular data info and descriptive statistics.

---

##  Use Cases

###  Student Manager
- University dashboards
- Admin tools for school databases
- Token-secured systems

###  EDA Automation
- ML pipeline preprocessing
- Instant exploratory analysis for uploaded datasets
- Dataset audit tools for analysts


##  Author

**Baksh Elahi**  
💬 GitHub: [github.com/BakshElahi4]  
